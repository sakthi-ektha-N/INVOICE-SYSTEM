﻿Public Class stockreport

    Private Sub stockreport_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DataSet2.tbl_stock' table. You can move, or remove it, as needed.
        Me.tbl_stockTableAdapter.Fill(Me.DataSet2.tbl_stock)

        Me.ReportViewer1.RefreshReport()
    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Form5.Show()
        Me.Hide()
    End Sub
End Class