﻿Imports System.Data.SqlClient
Public Class Form5
    Dim con As New SqlConnection
    Dim cmd As New SqlCommand
    Dim receiptID As Integer = 1

    Private Sub Btnadd_Click(sender As System.Object, e As System.EventArgs) Handles Btnadd.Click
        Dim barcode As Decimal = Decimal.Parse(Txtitemno.Text)
        Dim item_name As String = Txtitemname.Text
        Dim quantity As Decimal = Decimal.Parse(Txtqty.Text)
        Dim unit_price As Decimal = Decimal.Parse(Txtuprice.Text)
        Dim sum As Integer = quantity * unit_price
        DataGridView1.Rows.Add(barcode, item_name, unit_price, quantity, sum)
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "select STOCK_PRESENT from tbl_stock where ITEM_NUMBER ='" + Txtitemno.Text + "'"
        cmd.ExecuteNonQuery()
        Dim dt As New DataTable()
        Dim da As New SqlDataAdapter(cmd)
        da.Fill(dt)
        Dim stockcheck As Integer
        stockcheck = CType(cmd.ExecuteScalar(), Integer)
        stockcheck = stockcheck - quantity
        Dim cmd1 As New SqlCommand("update tbl_stock set STOCK_PRESENT='" & stockcheck & "',ITEM_NAME='" + Txtitemname.Text + "',UNIT_PRICE='" + Txtuprice.Text + "'where ITEM_NUMBER ='" + Txtitemno.Text + "'", con)
        cmd1.ExecuteNonQuery()
        calculate()
        'clear_boxes()
    End Sub
    Private Sub clear_boxes()
        Txtitemname.Clear()
        Txtqty.Clear()
        Txtuprice.Clear()
        Txtitemno.Clear()
        Txtitemno.Select()
    End Sub

    Private Sub Txtitemno_TextChanged(sender As System.Object, e As System.EventArgs) Handles Txtitemno.TextChanged
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "select ITEM_NAME,UNIT_PRICE from tbl_stock where ITEM_NUMBER='" + Txtitemno.Text + "'"

        cmd.ExecuteNonQuery()
        Dim dt As New DataTable()
        Dim da As New SqlDataAdapter(cmd)
        da.Fill(dt)
        If dt.Rows.Count() > 0 Then
            Txtitemname.Text = dt.Rows(0)(0).ToString()
            Txtuprice.Text = dt.Rows(0)(1).ToString()
        Else
            MessageBox.Show("NO SUCH ITEM EXIST")

        End If

    End Sub

    Private Sub Form5_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        con.ConnectionString = "Data Source=LAPTOP-054FFKJA\SQLEXPRESS;Initial Catalog=invoivedb;Integrated Security=True"
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()
        MessageBox.Show("connection established")
        'Txttax.Text = "5%"
        'autoid()
    End Sub
    'Public Sub autoid()
    '    Try
    '        cmd = New SqlCommand("select max(reciept_no) from tbl_bill")
    '        Dim dr As SqlDataReader = cmd.ExecuteScalar
    '        If dr.Read = True Then
    '            Me.TextBox1.Text = dr.Item(0) + 1
    '        Else
    '            Exit Sub
    '        End If

    '    Catch ex As Exception
    '        MsgBox(ex.Message)
    '    End Try

    'End Sub
    Private Sub calculate()
        Dim sum As Integer = 0
        ' Dim tax As Integer = 5
        For i = 0 To DataGridView1.Rows.Count - 1
            sum += DataGridView1.Rows(i).Cells(4).Value
            'sum = sum + ((sum * tax) / 100)
            
        Next
        Txttotal.Text = sum
    End Sub

    Private Sub Btnchange_Click(sender As System.Object, e As System.EventArgs) Handles Btnchange.Click
        If DataGridView1.SelectedRows.Count = 0 Then
            Exit Sub
        End If
        DataGridView1.Rows.Remove(DataGridView1.SelectedRows(0))
        calculate()
        Dim stockcheck As Integer
        Dim quantity As Decimal = Decimal.Parse(Txtqty.Text)
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "select STOCK_PRESENT from tbl_stock where ITEM_NUMBER ='" + Txtitemno.Text + "'"
        cmd.ExecuteNonQuery()
        Dim dt As New DataTable()
        Dim da As New SqlDataAdapter(cmd)
        da.Fill(dt)
        stockcheck = CType(cmd.ExecuteScalar(), Integer)
        stockcheck = stockcheck + quantity
        Dim cmd1 As New SqlCommand("update tbl_stock set STOCK_PRESENT='" & stockcheck & "',ITEM_NAME='" + Txtitemname.Text + "',UNIT_PRICE='" + Txtuprice.Text + "'where ITEM_NUMBER ='" + Txtitemno.Text + "'", con)
        cmd1.ExecuteNonQuery()
    End Sub

    Private Sub Btnprint_Click(sender As System.Object, e As System.EventArgs) Handles Btnprint.Click
        If DataGridView1.Rows.Count = 0 Then
            Exit Sub
        End If

        Dim cmd As New SqlCommand
        Try
            cmd = con.CreateCommand()
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "select max(reciept_no) from tbl_bill"

            cmd.ExecuteNonQuery()
            Dim dt As New DataTable()
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dt)
            receiptID = CType(cmd.ExecuteScalar(), Integer)
            receiptID += 1

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
            
            'Dim dt As New DataTable()
            'Dim da As New SqlDataAdapter(cmd)
            'da.Fill(dt)
            'cmd = New SqlCommand("select max(reciept_no) from tbl_bill")
            'Dim dr As SqlDataReader = cmd.ExecuteScalar
           
            'Dim cmd As New SqlCommand("INSERT INTO [dbo].[tbl_bill] VALUES(" & receiptID & ",'" + Txtcusname.Text + "','" + Txtcusphno.Text + "," + Txttotal.Text + "')", con)
        Dim cmd1 As New SqlCommand("insert into tbl_bill values(" & receiptID & ",'" + Txtcusname.Text + "'," + Txtcusphno.Text + "," + Txttotal.Text + ")", con)
        cmd1.ExecuteNonQuery()

            MessageBox.Show("YOU WILL BE PROVIDED YOUR RECEIPT IN FEW SECONDS")

            PrintPreviewDialog1.WindowState = FormWindowState.Maximized
            PrintPreviewDialog1.StartPosition = FormStartPosition.CenterScreen
            PrintPreviewDialog1.PrintPreviewControl.Zoom = 1.5
            PrintPreviewDialog1.Document = PrintDocument1
            PrintPreviewDialog1.ShowDialog()

            Button3_Click(Nothing, Nothing)

    End Sub

    Private Sub PrintDocument1_PrintPage(sender As System.Object, e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        'Count the Rows in the Bill
        Dim Rows As DataGridViewRowCollection = Me.DataGridView1.Rows


        'set Standard Width and Height
        Dim UnitWidth As Integer = 22
        Dim UnitHeight As Integer = 22

        Dim LeftMargin As Integer = 0
        Dim topMargin As Integer = 0


        ' Set the height of Bill Details part
        Dim ReciptDetailsHeight = Rows.Count * UnitHeight




        ' Standard Font
        Dim font As New Font("Times", 12)
        Dim fontB As New Font("Times", 12, FontStyle.Bold)

        Dim Fontbold As New Font("Times", 12, FontStyle.Bold)
        Dim FontboldHeader As New Font("Times", 16, FontStyle.Bold)


        'separate things for experiecne
        Dim TRecwidth As Integer = 283
        Dim Str As New StringFormat
        Str.Alignment = StringAlignment.Center
        Dim strLeft As New StringFormat
        strLeft.Alignment = StringAlignment.Near
        Dim strRight As New StringFormat
        strRight.Alignment = StringAlignment.Far

        'draw basic lines
        Dim YBillStart As Integer = 4 * UnitHeight

        'draw the headers
        Dim YHeaderStrat As Integer = YBillStart + (3 * UnitHeight)
        Dim YDetailsStart As Integer = YHeaderStrat + UnitHeight



        'Draw top rect
        Dim Rect As New Rectangle(LeftMargin + 0, topMargin + 0, TRecwidth, UnitHeight + 10)
        e.Graphics.DrawRectangle(Pens.White, Rect)
        Dim Rect1 As New Rectangle(LeftMargin + 0, topMargin + UnitHeight, TRecwidth * 2, UnitHeight)
        e.Graphics.DrawRectangle(Pens.White, Rect1)
        Dim Rect2 As New Rectangle(LeftMargin + 0, topMargin + UnitHeight * 2, TRecwidth, UnitHeight * 3)
        e.Graphics.DrawRectangle(Pens.White, Rect2)
        Dim Rect3 As New Rectangle(LeftMargin + 0, topMargin + UnitHeight * 4, TRecwidth, UnitHeight)
        e.Graphics.DrawRectangle(Pens.Black, Rect3)
        Dim Rect4 As New Rectangle(LeftMargin + 0, topMargin + UnitHeight * 5, TRecwidth, UnitHeight)
        e.Graphics.DrawRectangle(Pens.Black, Rect4)

        Dim DtValue As String = Format(Now.Date, "MMM-dd-yyyy")

        'Write Recipt No. & Recipt Date & Company Name
        e.Graphics.DrawString(Label1.Text, FontboldHeader, Brushes.Black, Rect, Str)
        e.Graphics.DrawString(Label2.Text, Fontbold, Brushes.Black, Rect1, Str)
        e.Graphics.DrawString(Label3.Text, Fontbold, Brushes.Black, Rect2, Str)
        e.Graphics.DrawString("Date: " & DtValue, font, Brushes.Black, Rect4, strLeft)
        e.Graphics.DrawString("Recipt No. " & receiptID, font, Brushes.Black, Rect3, strLeft)



        'Draw Black Line
        Dim Rect01 As New Rectangle(LeftMargin + UnitWidth * 0, topMargin + YHeaderStrat, UnitWidth * 1, UnitHeight)
        Dim Rect02 As New Rectangle(LeftMargin + UnitWidth * 1, topMargin + YHeaderStrat, UnitWidth * 6, UnitHeight)
        Dim Rect03 As New Rectangle(LeftMargin + UnitWidth * 7, topMargin + YHeaderStrat, UnitWidth * 2, UnitHeight)
        Dim Rect04 As New Rectangle(LeftMargin + UnitWidth * 9, topMargin + YHeaderStrat, UnitWidth * 2, UnitHeight)
        Dim Rect041 As New Rectangle(LeftMargin + UnitWidth * 11, topMargin + YHeaderStrat, UnitWidth * 2, UnitHeight)


        e.Graphics.DrawRectangle(Pens.Black, Rect01)
        e.Graphics.DrawRectangle(Pens.Black, Rect02)
        e.Graphics.DrawRectangle(Pens.Black, Rect03)
        e.Graphics.DrawRectangle(Pens.Black, Rect04)
        e.Graphics.DrawRectangle(Pens.Black, Rect041)

        'Fill Headers with Texts
        e.Graphics.DrawString("No", font, Brushes.Black, Rect01, Str)
        e.Graphics.DrawString("Item Name", font, Brushes.Black, Rect02, Str)
        e.Graphics.DrawString("Price", font, Brushes.Black, Rect03, Str)
        e.Graphics.DrawString("Qty", font, Brushes.Black, Rect04, Str)
        e.Graphics.DrawString("Sum", font, Brushes.Black, Rect041, Str)
        ''




        'Draw the details part
        e.Graphics.DrawRectangle(Pens.Black, LeftMargin + UnitWidth * 0, topMargin + YDetailsStart, UnitWidth * 1, ReciptDetailsHeight)
        e.Graphics.DrawRectangle(Pens.Black, LeftMargin + UnitWidth * 1, topMargin + YDetailsStart, UnitWidth * 6, ReciptDetailsHeight)
        e.Graphics.DrawRectangle(Pens.Black, LeftMargin + UnitWidth * 7, topMargin + YDetailsStart, UnitWidth * 2, ReciptDetailsHeight)
        e.Graphics.DrawRectangle(Pens.Black, LeftMargin + UnitWidth * 9, topMargin + YDetailsStart, UnitWidth * 2, ReciptDetailsHeight)
        e.Graphics.DrawRectangle(Pens.Black, LeftMargin + UnitWidth * 11, topMargin + YDetailsStart, UnitWidth * 2, ReciptDetailsHeight)


        'final part is to render the text into the image
        Dim I As Integer
        For I = 0 To Rows.Count - 1
            'find the Y
            Dim Yloc = UnitHeight * I + YDetailsStart


            Dim Rect1g As New Rectangle(LeftMargin + UnitWidth * 0, topMargin + Yloc, UnitWidth * 1, UnitHeight)
            Dim Rect2g As New Rectangle(LeftMargin + UnitWidth * 1, topMargin + Yloc, UnitWidth * 6, UnitHeight)
            Dim Rect3g As New Rectangle(LeftMargin + UnitWidth * 7, topMargin + Yloc, UnitWidth * 2, UnitHeight)
            Dim Rect4g As New Rectangle(LeftMargin + UnitWidth * 9, topMargin + Yloc, UnitWidth * 2, UnitHeight)
            Dim Rect5g As New Rectangle(LeftMargin + UnitWidth * 11, topMargin + Yloc, UnitWidth * 2, UnitHeight)



            'Serial Number
            e.Graphics.DrawString(I + 1, font, Brushes.Black, Rect1g, Str)
            'Item Name
            e.Graphics.DrawString(Rows(I).Cells(1).Value, font, Brushes.Black, Rect2g, strLeft)
            'Qty
            e.Graphics.DrawString(Rows(I).Cells(2).Value, font, Brushes.Black, Rect3g, Str)
            'Price
            e.Graphics.DrawString(Rows(I).Cells(3).Value, font, Brushes.Black, Rect4g, Str)
            'Sum
            e.Graphics.DrawString(Rows(I).Cells(4).Value, font, Brushes.Black, Rect5g, Str)

        Next


        'Render Total Items
        Dim Rect4x As New Rectangle(LeftMargin + 0, topMargin + ReciptDetailsHeight + YBillStart + 1 + (UnitHeight * 4), TRecwidth, UnitHeight)
        e.Graphics.DrawString("Total Items:  " & Rows.Count, font, Brushes.Black, Rect4x, strLeft)


        'Render the Total Bill Amount
        Dim Rect5 As New Rectangle(LeftMargin + 0, topMargin + ReciptDetailsHeight + YBillStart + 1 + (UnitHeight * 5), TRecwidth, UnitHeight)
        e.Graphics.DrawRectangle(Pens.Black, Rect5)
        Dim ReciptTotal As Decimal = Txttotal.Text
        e.Graphics.DrawString("Total Bill:  " & ReciptTotal, Fontbold, Brushes.Black, Rect5, Str)

    End Sub
   

    Private Sub CHECKSTOCKToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles CHECKSTOCKToolStripMenuItem.Click
        Form3.Show()
        Me.Hide()
    End Sub

    Private Sub LOGOUTToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles LOGOUTToolStripMenuItem.Click
        Me.Hide()
        Form1.Show()
    End Sub

    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click
        Txtcusname.Text = ""
        Txtcusphno.Text = ""
        DataGridView1.Rows.Clear()
        Txtitemno.Text = ""
        Txtitemname.Text = ""
        Txtqty.Text = ""
        Txtuprice.Text = ""
        Txttotal.Text = "0"
    End Sub

    Private Sub Txtqty_LostFocus(sender As Object, e As System.EventArgs) Handles Txtqty.LostFocus
        Dim quantity As Decimal = Decimal.Parse(Txtqty.Text)
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "select STOCK_PRESENT from tbl_stock where ITEM_NUMBER ='" + Txtitemno.Text + "'"
        cmd.ExecuteNonQuery()
        Dim dt As New DataTable()
        Dim da As New SqlDataAdapter(cmd)
        da.Fill(dt)
        Dim stockcheck As Integer
        stockcheck = CType(cmd.ExecuteScalar(), Integer)
        If quantity >= stockcheck Then
            MessageBox.Show(" STOCK INSUFFICIENT PLEASE REORDER")
            Me.Hide()
            Form3.Show()
        End If
    End Sub

    Private Sub TODAYSSALESToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles TODAYSSALESToolStripMenuItem.Click
        salesreport.Show()
        Me.Hide()
    End Sub

    Private Sub STOCKSALESToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles STOCKSALESToolStripMenuItem.Click
        stockreport.Show()
        Me.Hide()
    End Sub

    Private Sub DataGridView1_CellClick(sender As System.Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        'the try catch statement is used to handle any exception if formed.
        'using the index we select a particular row in the grid view data to undergo insert,update,del,search operation.
        Try
            If con.State = ConnectionState.Open Then
                con.Close()

            End If
            con.Open()
            Dim i As Integer
            i = e.RowIndex
            Dim selectedrow As DataGridViewRow
            selectedrow = DataGridView1.Rows(i)
            Txtitemno.Text = selectedrow.Cells(0).Value.ToString()
            Txtitemname.Text = selectedrow.Cells(1).Value.ToString()
            Txtuprice.Text = selectedrow.Cells(2).Value.ToString()
            Txtqty.Text = selectedrow.Cells(3).Value.ToString()

        Catch ex As Exception

        End Try
    End Sub
End Class