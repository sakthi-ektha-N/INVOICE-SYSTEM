﻿Imports System.Data.Sql
Imports System.Data.SqlClient
Public Class Form2
    Dim con As SqlConnection = New SqlConnection("Data Source=LAPTOP-054FFKJA\SQLEXPRESS;Initial Catalog=invoivedb;Integrated Security=True;Pooling=False")
    Dim cmd As SqlCommand
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        If con.State = ConnectionState.Open Then
            con.Close()
        Else
            con.Open()
        End If
        If TextBox1.Text = "" Then
            MsgBox("Enter username..", MsgBoxStyle.Critical)
        ElseIf TextBox2.Text = "" Then
            MsgBox("Enter password..", MsgBoxStyle.Critical)
        Else
            cmd = New SqlCommand("insert into tbl_login values('" + TextBox1.Text + "','" + TextBox2.Text + "')", con)
            cmd.ExecuteNonQuery()
            MsgBox("REGISTERED SUCCESSFULLY", MsgBoxStyle.Information)
            TextBox1.Clear()
            TextBox2.Clear()
            Form1.Show()
            Me.Hide()
        End If
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        TextBox1.Clear()
        TextBox2.Clear()
        Form1.Show()

    End Sub

    Private Sub REGISTER_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        TextBox1.Select()
    End Sub
End Class


