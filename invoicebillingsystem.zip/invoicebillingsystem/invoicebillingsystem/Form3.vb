﻿Imports System.Data.Sql
Imports System.Data.SqlClient
Public Class Form3
    Dim con As New SqlConnection
    Dim cmd As New SqlCommand()

    Private Sub Form3_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'InvoivedbDataSet.tbl_stock' table. You can move, or remove it, as needed.
        Me.Tbl_stockTableAdapter.Fill(Me.InvoivedbDataSet.tbl_stock)

        con.ConnectionString = "Data Source=LAPTOP-054FFKJA\SQLEXPRESS;Initial Catalog=invoivedb;Integrated Security=True;Pooling=False"
        If con.State = ConnectionState.Open Then
            con.Close()
        Else
            con.Open()
        End If
    End Sub
    Public Sub disp_data()
        'disp_data is a new subroutine created to display data in the grid view everytime a particluar button is click and the process is done.
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "select*from tbl_stock "
        cmd.ExecuteNonQuery()
        Dim dt As New DataTable()
        Dim da As New SqlDataAdapter(cmd)
        da.Fill(dt)
        DataGridView1.DataSource = dt
    End Sub
    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        disp_data()
    End Sub

  

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Dim cmd As New SqlCommand("insert into tbl_stock values(" + TextBox1.Text + ",'" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "')", con)
        cmd.ExecuteNonQuery()

        disp_data()
        MessageBox.Show("stock added successfully")

        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()

    End Sub

    Private Sub Button4_Click(sender As System.Object, e As System.EventArgs) Handles Button4.Click
        If con.State = ConnectionState.Open Then
            con.Close()

        End If
        con.Open()
        Dim cmd As SqlCommand = New SqlCommand("DELETE FROM [dbo].[tbl_stock] WHERE ITEM_NUMBER ='" + TextBox1.Text + "'", con)
        cmd.ExecuteNonQuery()

        disp_data()
        MessageBox.Show("stock deleted")

        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
    End Sub

    Private Sub Button6_Click(sender As System.Object, e As System.EventArgs) Handles Button6.Click
        If con.State = ConnectionState.Open Then
            con.Close()

        End If
        con.Open()
        MessageBox.Show("connection update")
        Dim cmd As New SqlCommand("update tbl_stock set ITEM_NAME='" + TextBox2.Text + "',STOCK_PRESENT='" + TextBox3.Text + "',UNIT_PRICE='" + TextBox4.Text + "' WHERE ITEM_NUMBER='" + TextBox1.Text + "'", con)
        cmd.ExecuteNonQuery()

        disp_data()
        MessageBox.Show("record updated")

        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
    End Sub

    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click
        Dim a As String
        a = InputBox("ENTER THE BARCODE", "SEARCH", "0")
        Dim da As New SqlDataAdapter("select*from tbl_stock where ITEM_NUMBER='" + a + "'", con)
        Dim ds As New DataSet()
        da.Fill(ds, "tbl_stock")
        DataGridView1.DataSource = ds.Tables("tbl_stock")
    End Sub

    Private Sub Button5_Click_1(sender As System.Object, e As System.EventArgs) Handles Button5.Click
        Form5.Show()
        Me.Hide()
    End Sub

    Private Sub DataGridView1_CellClick_1(sender As System.Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        'the try catch statement is used to handle any exception if formed.
        'using the index we select a particular row in the grid view data to undergo insert,update,del,search operation.
        Try
            If con.State = ConnectionState.Open Then
                con.Close()

            End If
            con.Open()
            Dim i As Integer
            i = e.RowIndex
            Dim selectedrow As DataGridViewRow
            selectedrow = DataGridView1.Rows(i)
            TextBox1.Text = selectedrow.Cells(0).Value.ToString()
            TextBox2.Text = selectedrow.Cells(1).Value.ToString()
            TextBox3.Text = selectedrow.Cells(2).Value.ToString()
            TextBox4.Text = selectedrow.Cells(3).Value.ToString()

        Catch ex As Exception

        End Try
    End Sub
End Class