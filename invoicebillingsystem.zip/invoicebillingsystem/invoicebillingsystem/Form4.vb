﻿Imports System.Data.Sql
Imports System.Data.SqlClient
Public Class Form4
        Dim con As New SqlConnection
        Dim cmd As New SqlCommand
        Dim cmd1 As New SqlCommand
        Dim receiptid As Integer = 1
        Dim sum As Integer

        Private Sub Form4_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        con.ConnectionString = "Data Source=LAPTOP-054FFKJA\SQLEXPRESS;Initial Catalog=invoivedb;Integrated Security=True;Pooling=False"
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()
        MessageBox.Show("connection established")
        Txttax.Text = "5%"
        TextBox1.Text = receiptid
        Txtitemno.Select()
        'Dim cmd As New SqlCommand("delete from tbl_grid", con)
        'cmd.ExecuteNonQuery()

        End Sub
    
    Private Sub calculate_invoice_total()
        Dim qty As Integer
        Dim sum As Integer = 0
        Dim tax As Integer = 5
        If sum = 0 Then

            MessageBox.Show("Kindly Bill Items")
        Else
            sum = sum + ((sum * tax) / 100)
            Txttotal.Text = sum
            Dim stockcheck As Integer
            stockcheck = stockcheck - qty
            Dim cmd1 As New SqlCommand("update tbl_stock set STOCK_PRESENT='" & stockcheck & "',customer_phno='" + Txtcusphno.Text + "',bill_amount='" + Txttotal.Text + "'where reciept_no='" & receiptid & "'", con)
            cmd1.ExecuteNonQuery()
        End If
        'For i = 0 To DataGridView1.Rows.Count - 1
        '    sum += DataGridView1.Rows(i).Cells(4).Value
        '    sum = sum + ((sum * tax) / 100)
        'Next
        'Txttotal.Text = sum
    End Sub
    Private Sub PrintDocument1_PrintPage(sender As System.Object, e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        'Count the Rows in the Bill
        Dim rowscount As Integer
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()
        rowscount = "count(barcode) from tbl_grid"
        rowscount = CType(cmd.ExecuteScalar(), Integer)

        'set Standard Width and Height
        Dim UnitWidth As Integer = 22
        Dim UnitHeight As Integer = 22

        Dim LeftMargin As Integer = 0
        Dim topMargin As Integer = 0


        ' Set the height of Bill Details part
        Dim ReciptDetailsHeight = rowscount * UnitHeight




        ' Standard Font
        Dim font As New Font("Times", 12)
        Dim fontB As New Font("Times", 12, FontStyle.Bold)

        Dim Fontbold As New Font("Times", 12, FontStyle.Bold)
        Dim FontboldHeader As New Font("Times", 16, FontStyle.Bold)


        'separate things for experiecne
        Dim TRecwidth As Integer = 283
        Dim Str As New StringFormat
        Str.Alignment = StringAlignment.Center
        Dim strLeft As New StringFormat
        strLeft.Alignment = StringAlignment.Near
        Dim strRight As New StringFormat
        strRight.Alignment = StringAlignment.Far

        'draw basic lines
        Dim YBillStart As Integer = 4 * UnitHeight

        'draw the headers
        Dim YHeaderStrat As Integer = YBillStart + (3 * UnitHeight)
        Dim YDetailsStart As Integer = YHeaderStrat + UnitHeight



        'Draw top rect
        Dim Rect As New Rectangle(LeftMargin + 0, topMargin + 0, TRecwidth, UnitHeight + 10)
        e.Graphics.DrawRectangle(Pens.White, Rect)
        Dim Rect1 As New Rectangle(LeftMargin + 0, topMargin + UnitHeight, TRecwidth, UnitHeight * 2)
        e.Graphics.DrawRectangle(Pens.White, Rect1)
        Dim Rect2 As New Rectangle(LeftMargin + 0, topMargin + UnitHeight * 2, TRecwidth, UnitHeight * 3)
        e.Graphics.DrawRectangle(Pens.White, Rect2)
        Dim Rect3 As New Rectangle(LeftMargin + 0, topMargin + UnitHeight * 4, TRecwidth, UnitHeight)
        e.Graphics.DrawRectangle(Pens.Black, Rect3)
        Dim Rect4 As New Rectangle(LeftMargin + 0, topMargin + UnitHeight * 5, TRecwidth, UnitHeight)
        e.Graphics.DrawRectangle(Pens.Black, Rect4)

        Dim DtValue As String = Format(Now.Date, "MMM-dd-yyyy")

        'Write Recipt No. & Recipt Date & Company Name
        e.Graphics.DrawString(Label1.Text, FontboldHeader, Brushes.Black, Rect, Str)
        e.Graphics.DrawString(Label2.Text, Fontbold, Brushes.Black, Rect1, Str)
        e.Graphics.DrawString(Label3.Text, Fontbold, Brushes.Black, Rect2, Str)
        e.Graphics.DrawString("Date: " & DtValue, font, Brushes.Black, Rect4, strLeft)
        e.Graphics.DrawString("Recipt No. " & receiptid, font, Brushes.Black, Rect3, strLeft)



        'Draw Black Line
        Dim Rect01 As New Rectangle(LeftMargin + UnitWidth * 0, topMargin + YHeaderStrat, UnitWidth * 1, UnitHeight)
        Dim Rect02 As New Rectangle(LeftMargin + UnitWidth * 1, topMargin + YHeaderStrat, UnitWidth * 6, UnitHeight)
        Dim Rect03 As New Rectangle(LeftMargin + UnitWidth * 7, topMargin + YHeaderStrat, UnitWidth * 2, UnitHeight)
        Dim Rect04 As New Rectangle(LeftMargin + UnitWidth * 9, topMargin + YHeaderStrat, UnitWidth * 2, UnitHeight)
        Dim Rect041 As New Rectangle(LeftMargin + UnitWidth * 11, topMargin + YHeaderStrat, UnitWidth * 2, UnitHeight)


        e.Graphics.DrawRectangle(Pens.Black, Rect01)
        e.Graphics.DrawRectangle(Pens.Black, Rect02)
        e.Graphics.DrawRectangle(Pens.Black, Rect03)
        e.Graphics.DrawRectangle(Pens.Black, Rect04)
        e.Graphics.DrawRectangle(Pens.Black, Rect041)

        'Fill Headers with Texts
        e.Graphics.DrawString("No.", font, Brushes.Black, Rect01, Str)
        e.Graphics.DrawString("Item Name", font, Brushes.Black, Rect02, Str)
        e.Graphics.DrawString("Qty", font, Brushes.Black, Rect03, Str)
        e.Graphics.DrawString("Price", font, Brushes.Black, Rect04, Str)
        e.Graphics.DrawString("Sum", font, Brushes.Black, Rect041, Str)
        ''




        'Draw the details part
        e.Graphics.DrawRectangle(Pens.Black, LeftMargin + UnitWidth * 0, topMargin + YDetailsStart, UnitWidth * 1, ReciptDetailsHeight)
        e.Graphics.DrawRectangle(Pens.Black, LeftMargin + UnitWidth * 1, topMargin + YDetailsStart, UnitWidth * 6, ReciptDetailsHeight)
        e.Graphics.DrawRectangle(Pens.Black, LeftMargin + UnitWidth * 7, topMargin + YDetailsStart, UnitWidth * 2, ReciptDetailsHeight)
        e.Graphics.DrawRectangle(Pens.Black, LeftMargin + UnitWidth * 9, topMargin + YDetailsStart, UnitWidth * 2, ReciptDetailsHeight)
        e.Graphics.DrawRectangle(Pens.Black, LeftMargin + UnitWidth * 11, topMargin + YDetailsStart, UnitWidth * 2, ReciptDetailsHeight)


        'final part is to render the text into the image
        Dim I As Integer
        For I = 0 To rowscount - 1
            'find the Y
            Dim Yloc = UnitHeight * I + YDetailsStart


            Dim Rect1g As New Rectangle(LeftMargin + UnitWidth * 0, topMargin + Yloc, UnitWidth * 1, UnitHeight)
            Dim Rect2g As New Rectangle(LeftMargin + UnitWidth * 1, topMargin + Yloc, UnitWidth * 6, UnitHeight)
            Dim Rect3g As New Rectangle(LeftMargin + UnitWidth * 7, topMargin + Yloc, UnitWidth * 2, UnitHeight)
            Dim Rect4g As New Rectangle(LeftMargin + UnitWidth * 9, topMargin + Yloc, UnitWidth * 2, UnitHeight)
            Dim Rect5g As New Rectangle(LeftMargin + UnitWidth * 11, topMargin + Yloc, UnitWidth * 2, UnitHeight)



            'Serial Number
            e.Graphics.DrawString(I + 1, font, Brushes.Black, Rect1g, Str)
            'Item Name
            Dim iname As String
            iname = "select item_name from tbl_grid where barcode='" + Txtitemno.Text + "'"
            iname = CType(cmd.ExecuteScalar(), Integer)
            e.Graphics.DrawString(iname, font, Brushes.Black, Rect2g, strLeft)
            'Qty
            Dim quanty As Integer
            quanty = "select quantity from tbl_grid where barcode='" + Txtitemno.Text + "'"
            quanty = CType(cmd.ExecuteScalar(), Integer)
            e.Graphics.DrawString(quanty, font, Brushes.Black, Rect3g, Str)
            'Price
            Dim unitprice As Integer
            unitprice = "select unit_price from tbl_grid where barcode='" + Txtitemno.Text + "'"
            unitprice = CType(cmd.ExecuteScalar(), Integer)
            e.Graphics.DrawString(unitprice, font, Brushes.Black, Rect4g, Str)
            ''Sum
            Dim sum As Integer
            sum = "select sum from tbl_grid where barcode='" + Txtitemno.Text + "'"
            sum = CType(cmd.ExecuteScalar(), Integer)
            e.Graphics.DrawString(sum, font, Brushes.Black, Rect5g, Str)

        Next


        'Render Total Items
        Dim Rect4x As New Rectangle(LeftMargin + 0, topMargin + ReciptDetailsHeight + YBillStart + 1 + (UnitHeight * 4), TRecwidth, UnitHeight)
        e.Graphics.DrawString("Total Items:  " & rowscount, font, Brushes.Black, Rect4x, strLeft)


        'Render the Total Bill Amount
        Dim Rect5 As New Rectangle(LeftMargin + 0, topMargin + ReciptDetailsHeight + YBillStart + 1 + (UnitHeight * 5), TRecwidth, UnitHeight)
        e.Graphics.DrawRectangle(Pens.Black, Rect5)
        Dim ReciptTotal As Decimal = Txttotal.Text
        e.Graphics.DrawString("Total Bill:  " & ReciptTotal, Fontbold, Brushes.Black, Rect5, Str)
    End Sub

    Private Sub Txtitemno_TextChanged_1(sender As System.Object, e As System.EventArgs) Handles Txtitemno.TextChanged
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "select ITEM_NAME,UNIT_PRICE from tbl_stock where ITEM_NUMBER='" + Txtitemno.Text + "'"
        cmd.ExecuteNonQuery()
        Dim dt As New DataTable()
        Dim da As New SqlDataAdapter(cmd)
        da.Fill(dt)
        If dt.Rows.Count() > 0 Then
            Txtitemname.Text = dt.Rows(0)(0).ToString()
            Txtuprice.Text = dt.Rows(0)(1).ToString()
        Else
            MessageBox.Show("NO SUCH ITEM EXIST")

        End If
    End Sub

    Private Sub CHECKSTOCKToolStripMenuItem_Click_1(sender As System.Object, e As System.EventArgs) Handles CHECKSTOCKToolStripMenuItem.Click
        Form3.Show()
        Me.Hide()
    End Sub

    Private Sub LOGOUTToolStripMenuItem_Click_1(sender As System.Object, e As System.EventArgs) Handles LOGOUTToolStripMenuItem.Click
        Form1.Show()
        Me.Hide()
    End Sub

    Private Sub Button2_Click_1(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        Dim cmd As New SqlCommand("delete from tbl_grid ", con)
        cmd.ExecuteNonQuery()
        Txtitemno.Select()
        Txtsum.Text = "0"
        Txttotal.Text = "0"
    End Sub

    Private Sub Btnadd_Click_1(sender As System.Object, e As System.EventArgs) Handles Btnadd.Click
        If con.State = ConnectionState.Open Then
            con.Close()

        End If
        con.Open()

        Dim itemnumber As Integer = Integer.Parse(Txtitemno.Text)
        Dim itemname As String = Txtitemname.Text
        Dim qty As Integer = Integer.Parse(Txtqty.Text)
        Dim price As Integer = Integer.Parse(Txtuprice.Text)
        sum = qty * price
        sum = Txtsum.Text
        Dim cmd As New SqlCommand("insert into tbl_grid values(" + Txtitemno.Text + ",'" + Txtitemname.Text + "','" + Txtqty.Text + "','" + Txtuprice.Text + "'," + Txtsum.Text + ")", con)
        cmd.ExecuteNonQuery()
        calculate_invoice_total()
        Dim cmd1 As New SqlCommand("update tbl_bill set customer_name='" + Txtcusname.Text + "',customer_phno='" + Txtcusphno.Text + "',bill_amount='" + Txttotal.Text + "'where reciept_no='" & receiptid & "'", con)
        cmd1.ExecuteNonQuery()
        MessageBox.Show(" record added successfully")

        Txtitemno.Select()

    End Sub

    Private Sub Btnchange_Click_1(sender As System.Object, e As System.EventArgs) Handles Btnchange.Click
        Dim a As String
        a = InputBox("PLEASE ENTER THE BARCODE", "SEARCH", "0")
        Dim da As New SqlDataAdapter("select*from tbl_grid where barcode='" + a + "'", con)
        Dim ds As New DataTable()
        If ds.Rows.Count() > 0 Then
            Txtitemno.Text = ds.Rows(0)(0).ToString()
            Txtitemname.Text = ds.Rows(0)(1).ToString()
            Txtqty.Text = ds.Rows(0)(2).ToString()
            Txtuprice.Text = ds.Rows(0)(3).ToString()
            Txtsum.Text = ds.Rows(0)(4).ToString()
        Else
            MessageBox.Show("NO SUCH ITEM EXIST")

        End If
    End Sub

    Private Sub Btnprint_Click_1(sender As System.Object, e As System.EventArgs) Handles Btnprint.Click
        'Dim da As New SqlDataAdapter("select*from tbl_grid where barcode='" + a + "'", con)
        Dim ds As New DataTable()
        If ds.Rows.Count() = 0 Then
            Exit Sub
        Else
            receiptid += 1

            PrintPreviewDialog1.WindowState = FormWindowState.Maximized
            PrintPreviewDialog1.StartPosition = FormStartPosition.CenterScreen
            PrintPreviewDialog1.PrintPreviewControl.Zoom = 1.5
            PrintPreviewDialog1.Document = PrintDocument1
            PrintPreviewDialog1.ShowDialog()


            Button2_Click_1(Nothing, Nothing)
        End If
    End Sub

    Private Sub Txtqty_TextChanged_1(sender As System.Object, e As System.EventArgs) Handles Txtqty.TextChanged
        Dim qty As Integer

        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "select STOCK_PRESENT from tbl_stock where ITEM_NUMBER ='" + Txtitemno.Text + "'"
        cmd.ExecuteNonQuery()
        Dim dt As New DataTable()
        Dim da As New SqlDataAdapter(cmd)
        da.Fill(dt)
        Dim stockcheck As Integer
        stockcheck = CType(cmd.ExecuteScalar(), Integer)
        If qty >= stockcheck Then
            MessageBox.Show(" STOCK INSUFFICIENT")
            Me.Hide()
            Form3.Show()
        End If
    End Sub
End Class
