﻿Imports System.Data
Imports System.Data.SqlClient

Public Class Form1
        Dim con As SqlConnection = New SqlConnection("Data Source=LAPTOP-054FFKJA\SQLEXPRESS;Initial Catalog=invoivedb;Integrated Security=True;Pooling=False")
        Dim cmd As SqlCommand

        Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
            'making this as mdi parent
        Dim invoiceF As New Form5
            invoiceF.MdiParent = Me

        Dim register As New Form2
            register.MdiParent = Me

        Dim stock As New Form3
            stock.MdiParent = Me

            TextBox1.Select()
        End Sub
        Private Sub Btnlogin_Click(sender As System.Object, e As System.EventArgs) Handles Btnlogin.Click
            If con.State = ConnectionState.Open Then
                con.Close()
            Else
                con.Open()
            End If

            If TextBox1.Text = "" Then
                MsgBox("Enter username..", MsgBoxStyle.Critical)
            ElseIf TextBox2.Text = "" Then
                MsgBox("Enter password..", MsgBoxStyle.Critical)
            End If
            Dim qry As String
            qry = "select *from tbl_login where username='" + TextBox1.Text + "'and password='" + TextBox2.Text + "'"
            cmd = New SqlCommand(qry, con)
            Dim da As SqlDataAdapter = New SqlDataAdapter(cmd)
            Dim ds As DataSet = New DataSet()
            da.Fill(ds)
            Dim a As Integer
            a = ds.Tables(0).Rows.Count
            If a = 0 Then
                MsgBox("Login fail!! Enter valid username and password", MsgBoxStyle.Critical)
            Else
                TextBox1.Clear()
                TextBox2.Clear()
            Form5.Show()
                Me.Hide()
            End If
        End Sub

        Private Sub Btncancel_Click(sender As System.Object, e As System.EventArgs) Handles Btncancel.Click
            TextBox1.Clear()
            TextBox2.Clear()
            End
        End Sub

        Private Sub LinkLabel1_LinkClicked(sender As System.Object, e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Form2.Show()
            Me.Hide()

        End Sub
    End Class
